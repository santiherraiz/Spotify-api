<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use App\Entity\Cancion;
use App\Entity\Artista;
use App\Entity\Album;
use App\Entity\Podcast;
use App\Entity\Capitulo;
use Symfony\Component\Serializer\SerializerInterface;

class CatalogoController extends AbstractController
{
    // GET /canciones
    public function canciones(Request $request, SerializerInterface $serializer): Response
    {
        $canciones = $this->getDoctrine()
            ->getRepository(Cancion::class)
            ->findAll();

        return $this->json($canciones, 200, [], ['groups' => ['cancion:read']]);
    }

    // GET /canciones/{cancionId}
    public function cancion(Request $request, SerializerInterface $serializer): Response
    {
        $id = $request->get('cancionId');

        $cancion = $this->getDoctrine()
            ->getRepository(Cancion::class)
            ->find($id);

        if (!$cancion) {
            return new Response('Canción no encontrada', 404);
        }

        return $this->json($cancion, 200, [], ['groups' => ['cancion:read_detail', 'album:read']]);
    }

    // GET /artistas
    public function artistas(Request $request, SerializerInterface $serializer): Response
    {
        $artistas = $this->getDoctrine()
            ->getRepository(Artista::class)
            ->findAll();

        return $this->json($artistas, 200, [], ['groups' => ['artista:read']]);
    }

    // GET /artistas/{artistaId}
    public function artista(Request $request, SerializerInterface $serializer): Response
    {
        $id = $request->get('artistaId');

        $artista = $this->getDoctrine()
            ->getRepository(Artista::class)
            ->find($id);

        if (!$artista) {
            return new Response('Artista no encontrado', 404);
        }

        return $this->json($artista, 200, [], ['groups' => ['artista:read']]);
    }

    // GET /artistas/{artistaId}/albums
    public function artistaAlbums(Request $request, SerializerInterface $serializer): Response
    {
        $id = $request->get('artistaId');

        $artista = $this->getDoctrine()
            ->getRepository(Artista::class)
            ->find($id);

        if (!$artista) {
            return new Response('Artista no encontrado', 404);
        }

        $albums = $this->getDoctrine()
            ->getRepository(Album::class)
            ->findBy(['artista' => $artista]);

        return $this->json($albums, 200, [], ['groups' => ['album:read']]);
    }

    // GET /artistas/{artistaId}/canciones
    public function artistaCanciones(Request $request, SerializerInterface $serializer): Response
    {
        $id = $request->get('artistaId');

        $artista = $this->getDoctrine()
            ->getRepository(Artista::class)
            ->find($id);

        if (!$artista) {
            return new Response('Artista no encontrado', 404);
        }

        $albums = $this->getDoctrine()
            ->getRepository(Album::class)
            ->findBy(['artista' => $artista]);

        $allCanciones = [];
        foreach ($albums as $album) {
            $canciones = $this->getDoctrine()
                ->getRepository(Cancion::class)
                ->findBy(['album' => $album]);
            
            foreach ($canciones as $cancion) {
                $allCanciones[] = $cancion;
            }
        }

        return $this->json($allCanciones, 200, [], ['groups' => ['cancion:read_detail', 'album:read']]);
    }

    // GET /albums
    public function albums(Request $request, SerializerInterface $serializer): Response
    {
        $albums = $this->getDoctrine()
            ->getRepository(Album::class)
            ->findAll();

        return $this->json($albums, 200, [], ['groups' => ['album:read']]);
    }

    // GET /albums/{albumId}
    public function album(Request $request, SerializerInterface $serializer): Response
    {
        $id = $request->get('albumId');

        $album = $this->getDoctrine()
            ->getRepository(Album::class)
            ->find($id);

        if (!$album) {
            return new Response('Álbum no encontrado', 404);
        }

        return $this->json($album, 200, [], ['groups' => ['album:read', 'album:read_detail']]);
    }

    // GET /albums/{albumId}/canciones
    public function albumCanciones(Request $request, SerializerInterface $serializer): Response
    {
        $id = $request->get('albumId');

        $album = $this->getDoctrine()
            ->getRepository(Album::class)
            ->find($id);

        if (!$album) {
            return new Response('Álbum no encontrado', 404);
        }

        $canciones = $this->getDoctrine()
            ->getRepository(Cancion::class)
            ->findBy(['album' => $album]);

        return $this->json($canciones, 200, [], ['groups' => ['cancion:read']]);
    }

    // GET /podcasts
    public function podcasts(Request $request, SerializerInterface $serializer): Response
    {
        $podcasts = $this->getDoctrine()
            ->getRepository(Podcast::class)
            ->findAll();

        return $this->json($podcasts, 200, [], ['groups' => ['podcast:read']]);
    }

    // GET /podcasts/{podcastId}
    public function podcast(Request $request, SerializerInterface $serializer): Response
    {
        $id = $request->get('podcastId');

        $podcast = $this->getDoctrine()
            ->getRepository(Podcast::class)
            ->find($id);

        if (!$podcast) {
            return new Response('Podcast no encontrado', 404);
        }

        return $this->json($podcast, 200, [], ['groups' => ['podcast:read']]);
    }

    // GET /podcasts/{podcastId}/capitulos
    public function podcastCapitulos(Request $request, SerializerInterface $serializer): Response
    {
        $id = $request->get('podcastId');

        $podcast = $this->getDoctrine()
            ->getRepository(Podcast::class)
            ->find($id);

        if (!$podcast) {
            return new Response('Podcast no encontrado', 404);
        }

        $capitulos = $this->getDoctrine()
            ->getRepository(Capitulo::class)
            ->findBy(['podcast' => $podcast]);

        return $this->json($capitulos, 200, [], ['groups' => ['capitulo:read']]);
    }

    // GET /capitulos/{capituloId}
    public function capitulo(Request $request, SerializerInterface $serializer): Response
    {
        $id = $request->get('capituloId');

        $capitulo = $this->getDoctrine()
            ->getRepository(Capitulo::class)
            ->find($id);

        if (!$capitulo) {
            return new Response('Capítulo no encontrado', 404);
        }

        return $this->json($capitulo, 200, [], ['groups' => ['capitulo:read', 'capitulo:read_detail']]);
    }
}
